"""End-to-end analysis pipeline.

Two phases, deliberately separated:

  ANALYZE (expensive, once per video):
      video file -> raw landmark arrays (extract.py) -> RawTake

  SOLVE (cheap, re-run on every Apply with current UI settings):
      RawTake + settings -> filtering -> occlusion inference -> root motion
      -> canonical skeleton -> MotionClip

This lets the artist tweak Smoothing / Confidence / Root Strength and re-apply
instantly without re-running pose detection.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import landmarks as L
from .filters import one_euro, savgol, smoothing_params
from .occlusion import fill_occlusions
from .rootmotion import apply_foot_locking, solve_root
from .solve import solve_skeleton


@dataclass
class RawTake:
    world: np.ndarray          # (F,33,3)
    image: np.ndarray          # (F,33,2)
    vis: np.ndarray            # (F,33)
    fps: float
    width: int
    height: int
    video_path: str = ""

    @property
    def n_frames(self):
        return int(self.world.shape[0])

    def save(self, path: str):
        np.savez_compressed(path, world=self.world, image=self.image,
                            vis=self.vis, fps=self.fps, width=self.width,
                            height=self.height,
                            video_path=np.array(self.video_path))

    @classmethod
    def load(cls, path: str) -> "RawTake":
        d = np.load(path, allow_pickle=False)
        return cls(world=d["world"], image=d["image"], vis=d["vis"],
                   fps=float(d["fps"]), width=int(d["width"]),
                   height=int(d["height"]),
                   video_path=str(d["video_path"]))


@dataclass
class Settings:
    confidence: float = 0.5        # visibility threshold
    smoothing: float = 0.5         # 0..1 UI level
    root_strength: float = 1.0     # scale on horizontal root motion
    foot_locking: bool = True
    speed_multiplier: float = 1.0  # playback speed scale
    max_gap_s: float = 0.5


@dataclass
class MotionClip:
    fps: float
    n_frames: int
    pos: dict                      # {bone: (F,3)} world head positions
    tail: dict
    quats: dict                    # {bone: (F,4)} world orientations
    root_trans: np.ndarray         # (F,3)
    contact_L: np.ndarray
    contact_R: np.ndarray
    segments: dict
    diagnostics: dict = field(default_factory=dict)


def build_clip(raw: RawTake, s: Settings, progress=None) -> MotionClip:
    def report(p, msg):
        if progress:
            progress(p, msg)

    fps = raw.fps
    world = raw.world.copy()
    vis = raw.vis.copy()

    # Occlusion filling MUST run before any temporal filtering: frames with
    # low-confidence garbage would otherwise be smeared into their neighbours.
    report(0.1, "Reconstructing occluded body parts...")
    world, info = fill_occlusions(world, vis, fps, s.confidence, s.max_gap_s)

    report(0.35, "Filtering landmarks...")
    min_cut, beta, win = smoothing_params(s.smoothing, fps)
    world = one_euro(world, fps, min_cutoff=min_cut, beta=beta)

    report(0.5, "Solving root motion...")
    root = solve_root(world, vis, info, fps, s.confidence, s.root_strength)

    report(0.65, "Smoothing...")
    world = savgol(world, win)
    trans = savgol(root["trans"], win)

    report(0.75, "Solving skeleton...")
    skel = solve_skeleton(world, trans, info)

    if s.foot_locking:
        report(0.9, "Locking foot contacts...")
        for side in ("L", "R"):
            segs = root[f"foot_lock_{side}"]
            locked = apply_foot_locking(skel["pos"][f"foot.{side}"], segs, fps)
            shift = locked - skel["pos"][f"foot.{side}"]
            skel["pos"][f"foot.{side}"] = locked
            skel["tail"][f"foot.{side}"] = skel["tail"][f"foot.{side}"] + shift

    gait = info["gait"]
    diagnostics = {
        "locomoting": bool(gait["locomoting"]),
        "cadence_hz": float(gait["cadence_hz"]),
        "synthetic_leg_frames": int(np.count_nonzero(info["synth_legs"])),
        "distance_m": float(np.linalg.norm(
            np.diff(trans[:, :2], axis=0), axis=1).sum()),
        "mean_visibility": float(vis.mean()),
        "valid_ratio": {k: float(v.mean()) for k, v in info["valid"].items()},
    }

    report(1.0, "Done")
    return MotionClip(
        fps=fps, n_frames=raw.n_frames,
        pos=skel["pos"], tail=skel["tail"], quats=skel["quats"],
        root_trans=trans,
        contact_L=root["contact_L"], contact_R=root["contact_R"],
        segments=info["segments"], diagnostics=diagnostics,
    )


def frame_times(clip: MotionClip, scene_fps: float, speed: float):
    """Map clip frames to scene frame numbers (float) honouring speed."""
    t = np.arange(clip.n_frames) / clip.fps          # seconds in video
    return 1.0 + t * scene_fps / max(speed, 1e-3)


__all__ = ["RawTake", "Settings", "MotionClip", "build_clip", "frame_times",
           "L"]
