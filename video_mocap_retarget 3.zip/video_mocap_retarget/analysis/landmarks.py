"""MediaPipe landmark indices + the canonical intermediate skeleton.

Coordinate convention used throughout the analysis core (Blender world):
    +X right, +Y forward (character facing +Y at identity), +Z up.
MediaPipe world landmarks are converted to this space in extract/solve.
"""

# --- MediaPipe Pose 33-landmark indices -----------------------------------
NOSE = 0
L_EYE_IN, L_EYE, L_EYE_OUT = 1, 2, 3
R_EYE_IN, R_EYE, R_EYE_OUT = 4, 5, 6
L_EAR, R_EAR = 7, 8
MOUTH_L, MOUTH_R = 9, 10
L_SHOULDER, R_SHOULDER = 11, 12
L_ELBOW, R_ELBOW = 13, 14
L_WRIST, R_WRIST = 15, 16
L_PINKY, R_PINKY = 17, 18
L_INDEX, R_INDEX = 19, 20
L_THUMB, R_THUMB = 21, 22
L_HIP, R_HIP = 23, 24
L_KNEE, R_KNEE = 25, 26
L_ANKLE, R_ANKLE = 27, 28
L_HEEL, R_HEEL = 29, 30
L_FOOT, R_FOOT = 31, 32  # foot index (toe tip)

N_LANDMARKS = 33

# Groups used for visibility gating / occlusion strategy
GROUPS = {
    "head": [NOSE, L_EYE, R_EYE, L_EAR, R_EAR],
    "torso": [L_SHOULDER, R_SHOULDER, L_HIP, R_HIP],
    "arm.L": [L_ELBOW, L_WRIST, L_PINKY, L_INDEX, L_THUMB],
    "arm.R": [R_ELBOW, R_WRIST, R_PINKY, R_INDEX, R_THUMB],
    "leg.L": [L_KNEE, L_ANKLE, L_HEEL, L_FOOT],
    "leg.R": [R_KNEE, R_ANKLE, R_HEEL, R_FOOT],
}

# --- Canonical skeleton -----------------------------------------------------
# Joint orientation frames are solved in solve.py.  Order matters (parents
# first) for FK synthesis of occluded limbs.
CANON_BONES = [
    "root",          # pelvis, carries root motion
    "spine",         # lower spine
    "chest",
    "neck",
    "head",
    "shoulder.L", "upper_arm.L", "forearm.L", "hand.L",
    "shoulder.R", "upper_arm.R", "forearm.R", "hand.R",
    "thigh.L", "shin.L", "foot.L", "toe.L",
    "thigh.R", "shin.R", "foot.R", "toe.R",
]

CANON_PARENT = {
    "root": None,
    "spine": "root", "chest": "spine", "neck": "chest", "head": "neck",
    "shoulder.L": "chest", "upper_arm.L": "shoulder.L",
    "forearm.L": "upper_arm.L", "hand.L": "forearm.L",
    "shoulder.R": "chest", "upper_arm.R": "shoulder.R",
    "forearm.R": "upper_arm.R", "hand.R": "forearm.R",
    "thigh.L": "root", "shin.L": "thigh.L", "foot.L": "shin.L", "toe.L": "foot.L",
    "thigh.R": "root", "shin.R": "thigh.R", "foot.R": "shin.R", "toe.R": "foot.R",
}

# Canonical REST directions (unit vectors, T-pose, facing +Y, Z up) and rest
# bending-plane normals.  direction = bone Y axis; normal seeds bone Z.
CANON_REST = {
    #                 direction            normal (bend plane ref)
    "root":        ((0, 0, 1),  (0, -1, 0)),
    "spine":       ((0, 0, 1),  (0, -1, 0)),
    "chest":       ((0, 0, 1),  (0, -1, 0)),
    "neck":        ((0, 0, 1),  (0, -1, 0)),
    "head":        ((0, 0, 1),  (0, -1, 0)),
    "shoulder.L":  ((1, 0, 0),  (0, -1, 0)),
    "upper_arm.L": ((1, 0, 0),  (0, -1, 0)),
    "forearm.L":   ((1, 0, 0),  (0, -1, 0)),
    "hand.L":      ((1, 0, 0),  (0, -1, 0)),
    "shoulder.R":  ((-1, 0, 0), (0, -1, 0)),
    "upper_arm.R": ((-1, 0, 0), (0, -1, 0)),
    "forearm.R":   ((-1, 0, 0), (0, -1, 0)),
    "hand.R":      ((-1, 0, 0), (0, -1, 0)),
    "thigh.L":     ((0, 0, -1), (0, -1, 0)),
    "shin.L":      ((0, 0, -1), (0, -1, 0)),
    "foot.L":      ((0, 1, 0),  (0, 0, 1)),
    "toe.L":       ((0, 1, 0),  (0, 0, 1)),
    "thigh.R":     ((0, 0, -1), (0, -1, 0)),
    "shin.R":      ((0, 0, -1), (0, -1, 0)),
    "foot.R":      ((0, 1, 0),  (0, 0, 1)),
    "toe.R":       ((0, 1, 0),  (0, 0, 1)),
}

# Default body segment lengths (meters) for an ~1.75 m adult; used when a
# segment was never observed with confidence and for gait synthesis.
DEFAULT_SEGMENTS = {
    "hip_width": 0.24,
    "shoulder_width": 0.38,
    "torso": 0.52,       # mid-hip -> mid-shoulder
    "neck": 0.11,
    "head": 0.22,
    "upper_arm": 0.30,
    "forearm": 0.27,
    "hand": 0.18,
    "thigh": 0.44,
    "shin": 0.43,
    "foot": 0.22,        # ankle -> toe tip (projected)
    "heel": 0.07,
}
