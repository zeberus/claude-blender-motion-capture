"""Analysis core: pure numpy + (optional) mediapipe. No bpy imports here."""
