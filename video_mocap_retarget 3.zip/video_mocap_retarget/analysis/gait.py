"""Locomotion analysis + procedural gait synthesis.

When the lower body is occluded we cannot track it — but we can usually
*infer* it: arm swing, shoulder sway and vertical bobbing of the torso betray
the gait phase and cadence.  This module

1. detects whether the performer is locomoting and at what cadence/phase
   from whatever upper-body signal is available, and
2. synthesises biomechanically plausible leg joint angles (hip/knee/ankle)
   for a walk/run cycle locked to that phase, from which solve-side FK
   produces landmark positions for the hidden legs.

The gait curves are compact sinusoid approximations of clinical gait
kinematics (Winter, "Biomechanics and Motor Control of Human Movement").
They are not motion-capture-accurate, but they are natural, foot-plant
consistent, and vastly better than frozen limbs.
"""
from __future__ import annotations

import numpy as np

from . import landmarks as L


# ---------------------------------------------------------------------------
# Cadence / phase detection
# ---------------------------------------------------------------------------
def _dominant_freq(sig: np.ndarray, fps: float,
                   fmin: float = 0.5, fmax: float = 3.6):
    """Dominant frequency (Hz) + strength (0..1) of a 1-D signal via FFT."""
    sig = np.asarray(sig, float)
    F = sig.shape[0]
    if F < int(fps):  # need at least ~1 s
        return 0.0, 0.0
    sig = sig - sig.mean()
    w = np.hanning(F)
    spec = np.abs(np.fft.rfft(sig * w))
    freqs = np.fft.rfftfreq(F, d=1.0 / fps)
    band = (freqs >= fmin) & (freqs <= fmax)
    if not band.any() or spec.sum() < 1e-9:
        return 0.0, 0.0
    i = np.argmax(spec * band)
    strength = float(spec[i] / (spec[band].sum() + 1e-9))
    return float(freqs[i]), strength


def analyze_gait(world: np.ndarray, vis: np.ndarray, fps: float,
                 conf_thresh: float, root_speed: np.ndarray | None = None):
    """Estimate per-frame locomotion state from upper-body motion.

    world: (F,33,3) landmarks in Blender space (pelvis-relative ok)
    root_speed: optional (F,) horizontal root speed (m/s) if already known.

    Returns dict with:
      cadence_hz    step frequency (per single step)
      phase         (F,) gait phase of the LEFT leg cycle in [0,1)
      locomoting    bool
      run_factor    0=walk .. 1=run
      speed         (F,) estimated forward speed m/s
    """
    F = world.shape[0]
    out = {"cadence_hz": 0.0, "phase": np.zeros(F), "locomoting": False,
           "run_factor": 0.0, "speed": np.zeros(F)}
    if F < 8:
        return out

    # Candidate periodic signals, best-confidence first ---------------------
    def _sig(idx_a, idx_b, comp):
        ok = (vis[:, idx_a] > conf_thresh) & (vis[:, idx_b] > conf_thresh)
        if ok.mean() < 0.5:
            return None
        return world[:, idx_a, comp] - world[:, idx_b, comp]

    candidates = []
    # arm swing (fore/aft wrist opposition) — strongest gait tell
    s = _sig(L.L_WRIST, L.R_WRIST, 1)
    if s is not None:
        candidates.append(("arms", s, 1.0))          # 1 cycle per stride
    s = _sig(L.L_ELBOW, L.R_ELBOW, 1)
    if s is not None:
        candidates.append(("elbows", s, 1.0))
    # shoulder sway (roll) — 1 cycle per stride
    s = _sig(L.L_SHOULDER, L.R_SHOULDER, 2)
    if s is not None:
        candidates.append(("sway", s, 1.0))
    # vertical bob of shoulder midpoint — 2 cycles per stride
    ok = (vis[:, L.L_SHOULDER] > conf_thresh) & (vis[:, L.R_SHOULDER] > conf_thresh)
    if ok.mean() >= 0.5:
        bob = 0.5 * (world[:, L.L_SHOULDER, 2] + world[:, L.R_SHOULDER, 2])
        candidates.append(("bob", bob, 2.0))

    best = None
    for name, sig, cycles_per_stride in candidates:
        f, strength = _dominant_freq(sig, fps)
        if f <= 0:
            continue
        stride_hz = f / cycles_per_stride       # full L+R stride frequency
        score = strength
        if best is None or score > best[3]:
            best = (name, sig, stride_hz, score, cycles_per_stride)

    if best is None:
        return out
    name, sig, stride_hz, strength, cps = best

    step_hz = stride_hz * 2.0                    # steps per second
    amp = float(np.std(sig))
    moving = strength > 0.25 and 0.4 <= stride_hz <= 1.9

    # amplitude sanity: require some real oscillation (meters)
    min_amp = 0.008 if name == "bob" else 0.03
    if amp < min_amp:
        moving = False
    if root_speed is not None and np.nanmedian(root_speed) > 0.35:
        moving = True                            # trajectory says we move
    if not moving:
        return out

    # Instantaneous phase via analytic-signal-lite: unwrap angle of the
    # dominant band using a numpy Hilbert transform.
    ph = _phase_of(sig, fps, stride_hz * cps) / cps
    # Align: define phase 0 = left foot strike.  For arm-swing signal
    # (L wrist forward = +Y diff max) left arm forward corresponds to RIGHT
    # foot strike, i.e. left-leg phase 0.5 at signal max.
    if name in ("arms", "elbows"):
        ph = ph + 0.5
    elif name == "sway":
        ph = ph + 0.25
    ph = np.mod(ph, 1.0)

    # walk/run blend from cadence (walk ~1.6-2.2 steps/s, run > 2.6)
    run_factor = float(np.clip((step_hz - 2.3) / 0.8, 0.0, 1.0))

    # Speed estimate: stride length model (Grieve): stride ≈ leg_len * k
    leg = L.DEFAULT_SEGMENTS["thigh"] + L.DEFAULT_SEGMENTS["shin"]
    stride_len = leg * (0.8 + 0.9 * run_factor + 0.5 * min(step_hz / 2.0, 1.2))
    speed = np.full(F, stride_hz * stride_len)
    if root_speed is not None:
        good = np.isfinite(root_speed)
        if good.mean() > 0.5 and np.nanmedian(root_speed) > 0.1:
            speed = np.where(good, root_speed, speed)

    out.update(cadence_hz=step_hz, phase=ph, locomoting=True,
               run_factor=run_factor, speed=speed)
    return out


def _phase_of(sig: np.ndarray, fps: float, freq: float) -> np.ndarray:
    """Continuous phase (cycles) of ``sig`` around ``freq`` Hz."""
    sig = np.asarray(sig, float)
    sig = sig - sig.mean()
    F = sig.shape[0]
    spec = np.fft.fft(sig * np.hanning(F))
    freqs = np.fft.fftfreq(F, 1.0 / fps)
    # band-pass +/- 35 % around freq, positive freqs only (analytic signal)
    keep = (freqs > freq * 0.65) & (freqs < freq * 1.5)
    spec = np.where(keep, spec, 0)
    analytic = np.fft.ifft(spec * 2.0)
    phase = np.unwrap(np.angle(analytic)) / (2 * np.pi)
    # cos peaks at phase 0 -> signal max at phase 0
    return phase


# ---------------------------------------------------------------------------
# Procedural gait curves
# ---------------------------------------------------------------------------
def leg_angles(phase: np.ndarray, run_factor: float):
    """Sagittal joint angles (radians) for ONE leg over its cycle.

    phase: (F,) in [0,1), 0 = foot strike of this leg.
    Returns dict of arrays: hip (+ = flexion/forward), knee (+ = flexion),
    ankle (+ = dorsiflexion), plus normalized foot-contact weight (1=stance).
    """
    p = np.mod(np.asarray(phase, float), 1.0)
    two_pi = 2 * np.pi
    r = float(np.clip(run_factor, 0, 1))

    # Hip: sinusoid, max flexion just before strike (~phase 0.95)
    hip_amp = np.deg2rad(22 + 20 * r)
    hip = hip_amp * np.cos(two_pi * p) - np.deg2rad(4)

    # Knee: small stance flexion bump + large swing flexion peak (~0.72)
    stance_bump = np.deg2rad(12 + 10 * r) * np.exp(
        -0.5 * ((p - 0.14) / 0.08) ** 2)
    swing_peak = np.deg2rad(58 + 45 * r) * np.exp(
        -0.5 * ((p - 0.72) / 0.11) ** 2)
    knee = stance_bump + swing_peak + np.deg2rad(4)

    # Ankle: plantarflex at toe-off (~0.55), dorsiflex mid-swing
    ankle = (np.deg2rad(-16 - 8 * r) * np.exp(-0.5 * ((p - 0.55) / 0.07) ** 2)
             + np.deg2rad(6) * np.exp(-0.5 * ((p - 0.85) / 0.12) ** 2))

    # Stance weight: ~60 % duty cycle walking, ~35 % running
    duty = 0.62 - 0.27 * r
    d = np.minimum(np.abs(p - 0.0), np.abs(p - 1.0))
    contact = np.clip(1.0 - (np.mod(p, 1.0) / duty), 0, 1)
    contact = ((p < duty).astype(float)
               * (0.5 - 0.5 * np.cos(np.pi * np.clip((duty - p) / duty, 0, 1) * 2)))
    contact = np.clip(contact, 0, 1)
    _ = d
    return {"hip": hip, "knee": knee, "ankle": ankle, "contact": contact}


def synthesize_legs(world: np.ndarray, phase: np.ndarray, run_factor: float,
                    pelvis_frames: np.ndarray, segments: dict):
    """FK-generate leg landmark positions for a gait cycle.

    world:         (F,33,3) landmark array (modified copy returned)
    phase:         (F,) left-leg phase
    pelvis_frames: (F,3,3) pelvis orientation frames, columns (x=left->right
                   corrected to +x=character left, y=forward, z=up)
    segments:      body segment lengths
    Returns (world_out, contact_L, contact_R)
    """
    F = world.shape[0]
    out = np.array(world, copy=True)
    thigh = segments.get("thigh", L.DEFAULT_SEGMENTS["thigh"])
    shin = segments.get("shin", L.DEFAULT_SEGMENTS["shin"])
    foot = segments.get("foot", L.DEFAULT_SEGMENTS["foot"])
    hipw = segments.get("hip_width", L.DEFAULT_SEGMENTS["hip_width"])

    ang_L = leg_angles(phase, run_factor)
    ang_R = leg_angles(phase + 0.5, run_factor)

    x_ax = pelvis_frames[:, :, 0]      # character-left
    y_ax = pelvis_frames[:, :, 1]      # forward
    z_ax = pelvis_frames[:, :, 2]      # up
    mid_hip = 0.5 * (out[:, L.L_HIP] + out[:, L.R_HIP])

    for side, ang, hip_idx, knee_idx, ankle_idx, heel_idx, toe_idx, sgn in (
        ("L", ang_L, L.L_HIP, L.L_KNEE, L.L_ANKLE, L.L_HEEL, L.L_FOOT, +1),
        ("R", ang_R, L.R_HIP, L.R_KNEE, L.R_ANKLE, L.R_HEEL, L.R_FOOT, -1),
    ):
        hip_pos = mid_hip + sgn * 0.5 * hipw * x_ax
        # All rotations happen in the sagittal plane spanned by (y_ax, z_ax).
        # Thigh: rotate "down" (-z) forward by the hip flexion angle.
        ch, sh = np.cos(ang["hip"])[:, None], np.sin(ang["hip"])[:, None]
        thigh_dir = -z_ax * ch + y_ax * sh
        knee_pos = hip_pos + thigh * thigh_dir
        # Shin: hip angle minus knee flexion (knee bends backwards).
        a = ang["hip"] - ang["knee"]
        ca, sa = np.cos(a)[:, None], np.sin(a)[:, None]
        shin_dir = -z_ax * ca + y_ax * sa
        ankle_pos = knee_pos + shin * shin_dir
        # Foot: roughly perpendicular to shin +/- ankle dorsi/plantar flexion.
        fa = a + np.pi / 2 + ang["ankle"]
        cf, sf = np.cos(fa)[:, None], np.sin(fa)[:, None]
        foot_dir = -z_ax * cf + y_ax * sf
        toe_pos = ankle_pos + foot * foot_dir
        heel_pos = ankle_pos - 0.4 * foot * foot_dir - 0.03 * z_ax

        out[:, hip_idx] = hip_pos
        out[:, knee_idx] = knee_pos
        out[:, ankle_idx] = ankle_pos
        out[:, toe_idx] = toe_pos
        out[:, heel_idx] = heel_pos
        _ = side

    return out, ang_L["contact"], ang_R["contact"]
