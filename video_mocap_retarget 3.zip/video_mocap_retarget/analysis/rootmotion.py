"""World-space root motion reconstruction.

MediaPipe world landmarks are *pelvis-relative*: the skeleton pose is metric
and 3D, but global translation is lost.  We reconstruct it with
foot-contact odometry:

    While a foot is planted, that foot is stationary in the world.  Its
    apparent motion relative to the pelvis is therefore exactly the pelvis
    moving over it.  Integrating -delta(foot_rel_pelvis) over stance phases
    yields the pelvis trajectory — walking, running, turning, stopping and
    direction changes all fall out naturally, including traveled distance.

Fallbacks, in order, when no reliable stance is available on a frame:
  * synthetic gait speed along the current facing (legs occluded while
    locomoting — speed from cadence x stride model),
  * velocity decay toward zero (brief flight phases / jumps / unknown).

Vertical root motion = pelvis height over the ground plane, from the lowest
foot during contact (or the gait bob when synthetic).
"""
from __future__ import annotations

import numpy as np

from . import landmarks as L
from .filters import one_euro, savgol


def detect_contacts(world: np.ndarray, vis: np.ndarray, fps: float,
                    conf: float):
    """Per-foot contact probability from tracked landmarks.

    IMPORTANT: the input is *pelvis-relative*, so a planted foot is NOT
    stationary in these coordinates — it moves backwards under the pelvis at
    the walking speed while the swing foot travels forwards roughly twice as
    fast.  A foot is therefore classified as planted when it is
      (a) near the ground (lowest observed foot height),
      (b) slower than the other foot,
      (c) with small vertical velocity.
    Returns two (F,) contact weights in 0..1.
    """
    F = world.shape[0]
    feet = {}
    for side, ankle, heel, toe in (("L", L.L_ANKLE, L.L_HEEL, L.L_FOOT),
                                   ("R", L.R_ANKLE, L.R_HEEL, L.R_FOOT)):
        pts = world[:, [ankle, heel, toe]]
        z = pts[..., 2].min(axis=1)                        # lowest of foot
        v = np.zeros((F, 3))
        v[1:] = np.diff(world[:, ankle], axis=0) * fps
        v = savgol(v, 5)
        feet[side] = {
            "z": z,
            "speed": np.linalg.norm(v[:, :2], axis=1),
            "vz": np.abs(v[:, 2]),
            "seen": vis[:, ankle] > conf,
        }
    zmin = np.percentile(np.concatenate([feet["L"]["z"], feet["R"]["z"]]), 5)
    out = {}
    for side, other in (("L", "R"), ("R", "L")):
        f, o = feet[side], feet[other]
        height_w = np.clip(1.0 - (f["z"] - zmin) / 0.12, 0, 1)
        rel = o["speed"] - f["speed"]                      # + if we're slower
        slower_w = 1.0 / (1.0 + np.exp(-rel / 0.15))       # sigmoid
        vz_w = np.clip(1.0 - f["vz"] / 0.6, 0, 1)
        w = height_w * slower_w * vz_w * f["seen"]
        out[side] = savgol(w, 5).clip(0, 1)
    return out["L"], out["R"]


def solve_root(world: np.ndarray, vis: np.ndarray, info: dict, fps: float,
               conf: float, root_strength: float = 1.0):
    """Reconstruct global pelvis trajectory.

    world: pelvis-relative landmarks AFTER occlusion filling
    info:  dict from occlusion.fill_occlusions (contact_/gait/pelvis_frames)
    Returns dict:
      trans      (F,3) world pelvis translation
      contact_L/R (F,) final 0..1 contact weights (tracked or synthetic)
      foot_lock_L/R list of (start, end, world_pos) stance segments
    """
    F = world.shape[0]
    pf = info["pelvis_frames"]

    cL_t, cR_t = detect_contacts(world, vis, fps, conf)
    # merge with synthetic contacts on procedurally animated frames
    synth = info["synth_legs"]
    cL = np.where(synth, info["contact_L"], cL_t)
    cR = np.where(synth, info["contact_R"], cR_t)

    gait_speed = info["gait"]["speed"] if info["gait"]["locomoting"] else None

    mid_hip = 0.5 * (world[:, L.L_HIP] + world[:, L.R_HIP])
    rel_L = world[:, L.L_ANKLE] - mid_hip
    rel_R = world[:, L.R_ANKLE] - mid_hip

    vel = np.zeros((F, 3))
    for f in range(1, F):
        wl, wr = cL[f] * cL[f - 1], cR[f] * cR[f - 1]
        num = np.zeros(3)
        den = 0.0
        if wl > 0.15:
            num += -(rel_L[f] - rel_L[f - 1]) * wl
            den += wl
        if wr > 0.15:
            num += -(rel_R[f] - rel_R[f - 1]) * wr
            den += wr
        if den > 1e-6:
            vel[f] = num / den
            vel[f, 2] = 0.0                       # ground-plane odometry
        elif gait_speed is not None:
            # bridge flight phases / brief stance dropouts with model speed
            fwd = pf[f, :, 1]
            fwd = fwd / max(np.linalg.norm(fwd[:2]), 1e-6)
            vel[f, :2] = fwd[:2] * gait_speed[f] / fps
        else:
            vel[f] = vel[f - 1] * 0.85            # decay through unknown

    vel = one_euro(vel, fps, min_cutoff=1.2, beta=0.05)
    trans = np.cumsum(vel, axis=0)

    # ------- vertical: pelvis height over ground --------------------------
    foot_low = np.minimum(world[:, L.L_HEEL, 2], world[:, L.R_HEEL, 2])
    foot_low = np.minimum(foot_low, np.minimum(world[:, L.L_FOOT, 2],
                                               world[:, L.R_FOOT, 2]))
    pelvis_h = -foot_low                          # pelvis above lowest foot
    pelvis_h = savgol(pelvis_h, max(5, int(fps * 0.25) | 1))
    seen_any_foot = ((vis[:, L.L_ANKLE] > conf) | (vis[:, L.R_ANKLE] > conf)
                     | synth)
    if seen_any_foot.any():
        default_h = float(np.median(pelvis_h[seen_any_foot]))
    else:
        default_h = L.DEFAULT_SEGMENTS["thigh"] + L.DEFAULT_SEGMENTS["shin"]
    pelvis_h = np.where(seen_any_foot, pelvis_h, default_h)
    trans[:, 2] = pelvis_h

    trans[:, :2] *= float(np.clip(root_strength, 0.0, 2.0))
    trans[:, :2] -= trans[0:1, :2]                # start at origin

    locks_L = _stance_segments(cL, trans, world[:, L.L_ANKLE], mid_hip)
    locks_R = _stance_segments(cR, trans, world[:, L.R_ANKLE], mid_hip)

    return {"trans": trans, "contact_L": cL, "contact_R": cR,
            "foot_lock_L": locks_L, "foot_lock_R": locks_R}


def _stance_segments(contact: np.ndarray, trans: np.ndarray,
                     ankle_rel_pelvisless: np.ndarray, mid_hip: np.ndarray,
                     thresh: float = 0.5, min_len: int = 3):
    """Contiguous stance spans -> [(start, end, mean world ankle pos)]."""
    on = contact > thresh
    segs = []
    f = 0
    F = on.shape[0]
    ankle_world = trans + (ankle_rel_pelvisless - mid_hip)
    while f < F:
        if not on[f]:
            f += 1
            continue
        s = f
        while f < F and on[f]:
            f += 1
        if f - s >= min_len:
            pos = ankle_world[s:f].mean(axis=0)
            segs.append((s, f, pos))
    return segs


def apply_foot_locking(foot_world: np.ndarray, segments, fps: float,
                       blend_s: float = 0.12):
    """Pin foot world positions during stance segments, with soft blends.

    foot_world: (F,3) world-space foot target curve (modified copy returned)
    """
    out = np.array(foot_world, copy=True)
    r = max(1, int(round(blend_s * fps)))
    F = out.shape[0]
    for s, e, pos in segments:
        pin = pos.copy()
        pin[2] = np.median(out[s:e, 2])          # keep solved height
        out[s:e, :2] = pin[:2]
        for k in range(1, r + 1):                # cosine blend in/out
            a = 0.5 - 0.5 * np.cos(np.pi * k / (r + 1))
            if s - k >= 0:
                out[s - k, :2] = out[s - k, :2] * a + pin[:2] * (1 - a)
            if e - 1 + k < F:
                out[e - 1 + k, :2] = out[e - 1 + k, :2] * a + pin[:2] * (1 - a)
    return out
