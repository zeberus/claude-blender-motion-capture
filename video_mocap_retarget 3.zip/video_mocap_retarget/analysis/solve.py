"""Solve the canonical skeleton from filled landmark arrays.

For every canonical bone we produce, per frame:
  * a world-space orientation frame (3x3, columns x/y/z, bone axis = Y,
    Blender convention), built from the bone direction and a bending-plane
    normal, and
  * head/tail world positions (root-motion translation already applied).

Retargeting then only needs to match these world orientations on the target
rig — which is robust to rest-pose differences (T-pose vs A-pose) and to
differing bone rolls, because we align *directions*, not local channels.
"""
from __future__ import annotations

import numpy as np

from . import landmarks as L
from .quat import frame_from_dir_normal, hemispherize, normalize, quat_from_mat

# midpoint helpers -----------------------------------------------------------


def _mid(world, a, b):
    return 0.5 * (world[:, a] + world[:, b])


def solve_skeleton(world: np.ndarray, trans: np.ndarray, info: dict):
    """Return dict:
        pos    {bone: (F,3) head world position}
        tail   {bone: (F,3) tail world position}
        frames {bone: (F,3,3) world orientation}
        quats  {bone: (F,4)  world orientation quaternion, hemispherized}
    """
    F = world.shape[0]
    w = world - _mid(world, L.L_HIP, L.R_HIP)[:, None, :]  # pelvis-centered
    w = w + trans[:, None, :]                              # + root motion

    seg = info["segments"]
    pos, tail, frames = {}, {}, {}

    mid_hip = _mid(w, L.L_HIP, L.R_HIP)
    mid_sho = _mid(w, L.L_SHOULDER, L.R_SHOULDER)

    # --- torso column ------------------------------------------------------
    up = normalize(mid_sho - mid_hip)
    left = normalize(w[:, L.L_HIP] - w[:, L.R_HIP])
    left_s = normalize(w[:, L.L_SHOULDER] - w[:, L.R_SHOULDER])
    back_lo = normalize(np.cross(left, up))      # -forward at pelvis
    back_hi = normalize(np.cross(left_s, up))

    spine_len = np.linalg.norm(mid_sho - mid_hip, axis=-1, keepdims=True)
    p_root = mid_hip
    p_spine = mid_hip + up * spine_len * 0.33
    p_chest = mid_hip + up * spine_len * 0.66

    pos["root"], tail["root"] = p_root, p_spine
    frames["root"] = frame_from_dir_normal(up, back_lo)
    pos["spine"], tail["spine"] = p_spine, p_chest
    frames["spine"] = frame_from_dir_normal(
        normalize(p_chest - p_spine), normalize(back_lo + back_hi))
    pos["chest"], tail["chest"] = p_chest, mid_sho
    frames["chest"] = frame_from_dir_normal(
        normalize(mid_sho - p_chest), back_hi)

    # --- head / neck ---------------------------------------------------------
    ear_mid = _mid(w, L.L_EAR, L.R_EAR)
    nose = w[:, L.NOSE]
    head_up = normalize(ear_mid - mid_sho)
    neck_dir = normalize(0.6 * head_up + 0.4 * up)
    p_neck = mid_sho
    p_head = mid_sho + neck_dir * seg.get("neck", 0.11)
    head_fwd = normalize(nose - ear_mid)
    pos["neck"], tail["neck"] = p_neck, p_head
    frames["neck"] = frame_from_dir_normal(neck_dir, -head_fwd)
    head_dir = normalize(np.cross(normalize(w[:, L.L_EAR] - w[:, L.R_EAR]),
                                  head_fwd))
    # ensure head Y points up-ish
    flip = (np.sum(head_dir * up, axis=-1) < 0)[:, None]
    head_dir = np.where(flip, -head_dir, head_dir)
    pos["head"] = p_head
    tail["head"] = p_head + head_dir * seg.get("head", 0.22)
    frames["head"] = frame_from_dir_normal(head_dir, -head_fwd)

    # --- limbs ---------------------------------------------------------------
    def limb(prefix, side, sh, el, wr, hip_anchor=None):
        s, e, h = w[:, sh], w[:, el], w[:, wr]
        d1, d2 = normalize(e - s), normalize(h - e)
        bend = np.cross(d1, d2)                    # bending-plane normal
        small = np.linalg.norm(bend, axis=-1, keepdims=True) < 5e-2
        # nearly straight limb: use body-derived normal (backwards for arms,
        # forward for legs -> knee points forward)
        default = back_hi if prefix == "upper_arm" else -back_lo
        bend = normalize(np.where(small, default, normalize(bend)))
        if side == "R" and prefix == "upper_arm":
            pass
        return s, e, h, d1, d2, bend

    for side, SH, EL, WR, IX, PK in (("L", L.L_SHOULDER, L.L_ELBOW, L.L_WRIST,
                                      L.L_INDEX, L.L_PINKY),
                                     ("R", L.R_SHOULDER, L.R_ELBOW, L.R_WRIST,
                                      L.R_INDEX, L.R_PINKY)):
        s, e, h, d1, d2, bend = limb("upper_arm", side, SH, EL, WR)
        # clavicle
        pos[f"shoulder.{side}"] = mid_sho
        tail[f"shoulder.{side}"] = s
        frames[f"shoulder.{side}"] = frame_from_dir_normal(
            normalize(s - mid_sho), back_hi)
        pos[f"upper_arm.{side}"], tail[f"upper_arm.{side}"] = s, e
        frames[f"upper_arm.{side}"] = frame_from_dir_normal(d1, bend)
        pos[f"forearm.{side}"], tail[f"forearm.{side}"] = e, h
        frames[f"forearm.{side}"] = frame_from_dir_normal(d2, bend)
        # hand: direction wrist->knuckle-mid, normal = palm normal
        km = _mid(w, IX, PK)
        hd = normalize(km - h)
        palm_n = np.cross(w[:, IX] - h, w[:, PK] - h)
        if side == "R":
            palm_n = -palm_n
        n = np.linalg.norm(palm_n, axis=-1, keepdims=True)
        palm_n = np.where(n < 1e-6, bend, palm_n / np.maximum(n, 1e-9))
        pos[f"hand.{side}"] = h
        tail[f"hand.{side}"] = h + hd * seg.get("hand", 0.18)
        frames[f"hand.{side}"] = frame_from_dir_normal(hd, palm_n)

    for side, HP, KN, AN, HE, TO in (("L", L.L_HIP, L.L_KNEE, L.L_ANKLE,
                                      L.L_HEEL, L.L_FOOT),
                                     ("R", L.R_HIP, L.R_KNEE, L.R_ANKLE,
                                      L.R_HEEL, L.R_FOOT)):
        hp, kn, an = w[:, HP], w[:, KN], w[:, AN]
        d1, d2 = normalize(kn - hp), normalize(an - kn)
        bend = np.cross(d1, d2)
        small = np.linalg.norm(bend, axis=-1, keepdims=True) < 5e-2
        # straight leg: knee normal = character left/right axis so knees
        # keep pointing forward (frame z = -bend x? use -back_lo forward)
        bend = np.where(small, normalize(np.cross(d1, -back_lo)), bend)
        bend = normalize(bend)
        pos[f"thigh.{side}"], tail[f"thigh.{side}"] = hp, kn
        frames[f"thigh.{side}"] = frame_from_dir_normal(d1, bend)
        pos[f"shin.{side}"], tail[f"shin.{side}"] = kn, an
        frames[f"shin.{side}"] = frame_from_dir_normal(d2, bend)
        fd = normalize(w[:, TO] - w[:, HE])
        foot_up = normalize(np.cross(fd, normalize(w[:, HE] - an) + 1e-9))
        pos[f"foot.{side}"], tail[f"foot.{side}"] = an, w[:, TO]
        frames[f"foot.{side}"] = frame_from_dir_normal(fd, up)
        pos[f"toe.{side}"] = w[:, TO]
        tail[f"toe.{side}"] = w[:, TO] + fd * 0.05
        frames[f"toe.{side}"] = frame_from_dir_normal(fd, up)
        _ = foot_up

    quats = {b: hemispherize(quat_from_mat(frames[b])) for b in frames}
    assert all(b in frames for b in L.CANON_BONES), "missing canonical bones"
    _ = F
    return {"pos": pos, "tail": tail, "frames": frames, "quats": quats}
