"""Small numpy quaternion / vector toolbox (w, x, y, z convention).

Pure numpy so the analysis core can be developed and unit-tested outside
Blender.  Inside Blender the bpy layer converts to mathutils at the boundary.
"""
from __future__ import annotations

import numpy as np

EPS = 1e-9


def normalize(v: np.ndarray, axis: int = -1) -> np.ndarray:
    n = np.linalg.norm(v, axis=axis, keepdims=True)
    return v / np.maximum(n, EPS)


def qmul(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    aw, ax, ay, az = np.moveaxis(a, -1, 0)
    bw, bx, by, bz = np.moveaxis(b, -1, 0)
    return np.stack(
        (
            aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
        ),
        axis=-1,
    )


def qconj(q: np.ndarray) -> np.ndarray:
    out = np.array(q, copy=True)
    out[..., 1:] *= -1.0
    return out


def qnormalize(q: np.ndarray) -> np.ndarray:
    return normalize(q)


def qrot(q: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Rotate vector(s) v by quaternion(s) q."""
    qv = np.concatenate([np.zeros(v.shape[:-1] + (1,)), v], axis=-1)
    return qmul(qmul(q, qv), qconj(q))[..., 1:]


def quat_from_two_vectors(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Shortest-arc rotation taking unit vector a to unit vector b."""
    a = normalize(a)
    b = normalize(b)
    d = np.sum(a * b, axis=-1, keepdims=True)
    axis = np.cross(a, b)
    w = 1.0 + d
    q = np.concatenate([w, axis], axis=-1)
    # antiparallel fallback: rotate 180 deg around any perpendicular axis
    bad = (w < 1e-6)[..., 0]
    if np.any(bad):
        a_bad = np.atleast_2d(a.reshape(-1, 3)[bad.reshape(-1)])
        perp = np.cross(a_bad, np.array([1.0, 0.0, 0.0]))
        small = np.linalg.norm(perp, axis=-1) < 1e-6
        perp[small] = np.cross(a_bad[small], np.array([0.0, 1.0, 0.0]))
        perp = normalize(perp)
        qf = q.reshape(-1, 4)
        qf[bad.reshape(-1)] = np.concatenate(
            [np.zeros((perp.shape[0], 1)), perp], axis=-1
        )
        q = qf.reshape(q.shape)
    return qnormalize(q)


def mat_from_quat(q: np.ndarray) -> np.ndarray:
    w, x, y, z = np.moveaxis(qnormalize(q), -1, 0)
    m = np.empty(q.shape[:-1] + (3, 3))
    m[..., 0, 0] = 1 - 2 * (y * y + z * z)
    m[..., 0, 1] = 2 * (x * y - z * w)
    m[..., 0, 2] = 2 * (x * z + y * w)
    m[..., 1, 0] = 2 * (x * y + z * w)
    m[..., 1, 1] = 1 - 2 * (x * x + z * z)
    m[..., 1, 2] = 2 * (y * z - x * w)
    m[..., 2, 0] = 2 * (x * z - y * w)
    m[..., 2, 1] = 2 * (y * z + x * w)
    m[..., 2, 2] = 1 - 2 * (x * x + y * y)
    return m


def quat_from_mat(m: np.ndarray) -> np.ndarray:
    """Rotation matrix (…,3,3) -> quaternion (…,4). Shepperd's method."""
    m = np.asarray(m)
    shape = m.shape[:-2]
    m = m.reshape(-1, 3, 3)
    q = np.empty((m.shape[0], 4))
    t = np.trace(m, axis1=-2, axis2=-1)
    for i in range(m.shape[0]):
        M = m[i]
        if t[i] > 0:
            s = np.sqrt(t[i] + 1.0) * 2
            q[i] = [0.25 * s, (M[2, 1] - M[1, 2]) / s,
                    (M[0, 2] - M[2, 0]) / s, (M[1, 0] - M[0, 1]) / s]
        elif M[0, 0] >= M[1, 1] and M[0, 0] >= M[2, 2]:
            s = np.sqrt(1.0 + M[0, 0] - M[1, 1] - M[2, 2]) * 2
            q[i] = [(M[2, 1] - M[1, 2]) / s, 0.25 * s,
                    (M[0, 1] + M[1, 0]) / s, (M[0, 2] + M[2, 0]) / s]
        elif M[1, 1] >= M[2, 2]:
            s = np.sqrt(1.0 + M[1, 1] - M[0, 0] - M[2, 2]) * 2
            q[i] = [(M[0, 2] - M[2, 0]) / s, (M[0, 1] + M[1, 0]) / s,
                    0.25 * s, (M[1, 2] + M[2, 1]) / s]
        else:
            s = np.sqrt(1.0 + M[2, 2] - M[0, 0] - M[1, 1]) * 2
            q[i] = [(M[1, 0] - M[0, 1]) / s, (M[0, 2] + M[2, 0]) / s,
                    (M[1, 2] + M[2, 1]) / s, 0.25 * s]
    return qnormalize(q.reshape(shape + (4,)))


def frame_from_dir_normal(direction: np.ndarray, normal: np.ndarray) -> np.ndarray:
    """Build right-handed orthonormal frames (…,3,3) with columns (x, y, z):

    y  = ``direction`` (bone axis, Blender convention)
    z  = component of ``normal`` orthogonal to y (bending-plane reference)
    x  = y cross z
    """
    y = normalize(direction)
    z = normal - np.sum(normal * y, axis=-1, keepdims=True) * y
    nz = np.linalg.norm(z, axis=-1, keepdims=True)
    # degenerate: pick any perpendicular
    fallback = np.cross(y, np.array([1.0, 0.0, 0.0]))
    fb_small = np.linalg.norm(fallback, axis=-1, keepdims=True) < 1e-6
    fallback = np.where(fb_small, np.cross(y, np.array([0.0, 0.0, 1.0])), fallback)
    z = np.where(nz < 1e-6, fallback, z)
    z = normalize(z)
    x = np.cross(y, z)
    return np.stack([x, y, z], axis=-1)


def slerp(q0: np.ndarray, q1: np.ndarray, t) -> np.ndarray:
    q0 = qnormalize(q0)
    q1 = qnormalize(q1)
    d = np.sum(q0 * q1, axis=-1, keepdims=True)
    q1 = np.where(d < 0, -q1, q1)
    d = np.abs(d)
    t = np.asarray(t)[..., None] if np.ndim(t) else t
    lin = qnormalize(q0 + (q1 - q0) * t)  # fallback for near-identical
    theta = np.arccos(np.clip(d, -1.0, 1.0))
    s = np.sin(theta)
    with np.errstate(invalid="ignore", divide="ignore"):
        out = (np.sin((1 - t) * theta) * q0 + np.sin(t * theta) * q1) / s
    return qnormalize(np.where(s < 1e-5, lin, out))


def hemispherize(q: np.ndarray) -> np.ndarray:
    """Flip signs along the frame axis (axis 0) so consecutive quats are
    in the same hemisphere -> smooth curves after keyframing."""
    q = np.array(q, copy=True)
    for f in range(1, q.shape[0]):
        flip = np.sum(q[f] * q[f - 1], axis=-1) < 0
        q[f][flip] *= -1.0
    return q
