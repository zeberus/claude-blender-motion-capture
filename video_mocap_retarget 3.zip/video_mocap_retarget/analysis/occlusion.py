"""Occlusion / partial-visibility handling.

Strategy per landmark group:
  1. Frames with visibility above the confidence threshold are trusted.
  2. Short gaps (joint reappears) are interpolated.
  3. Legs occluded during detected locomotion are re-synthesised with the
     procedural gait model, phase-locked to the upper body (gait.py).
  4. Anything else falls back to "hold with relaxation": keep the last
     confident pose relative to its parent group and ease it toward a
     neutral pose — limbs never freeze in world space and never snap.

Everything operates on pelvis-relative world landmarks (F,33,3).
"""
from __future__ import annotations

import numpy as np

from . import gait
from . import landmarks as L
from .filters import hold_edges, interpolate_gaps


def group_validity(vis: np.ndarray, conf: float):
    """Per-frame validity of each landmark group (majority of joints seen)."""
    out = {}
    for name, ids in L.GROUPS.items():
        v = vis[:, ids] > conf
        out[name] = v.mean(axis=1) >= 0.6
    return out


def measure_segments(world: np.ndarray, vis: np.ndarray, conf: float) -> dict:
    """Median body segment lengths from confident frames, with defaults."""
    seg = dict(L.DEFAULT_SEGMENTS)

    def med(a, b, key):
        ok = (vis[:, a] > conf) & (vis[:, b] > conf)
        if ok.sum() >= 5:
            d = np.linalg.norm(world[ok, a] - world[ok, b], axis=-1)
            m = float(np.median(d))
            if 0.02 < m < 1.2:
                seg[key] = m

    med(L.L_HIP, L.R_HIP, "hip_width")
    med(L.L_SHOULDER, L.R_SHOULDER, "shoulder_width")
    med(L.L_SHOULDER, L.L_ELBOW, "upper_arm")
    med(L.L_ELBOW, L.L_WRIST, "forearm")
    med(L.L_HIP, L.L_KNEE, "thigh")
    med(L.L_KNEE, L.L_ANKLE, "shin")
    med(L.L_ANKLE, L.L_FOOT, "foot")
    ok = ((vis[:, L.L_HIP] > conf) & (vis[:, L.R_HIP] > conf)
          & (vis[:, L.L_SHOULDER] > conf) & (vis[:, R := L.R_SHOULDER] > conf))
    if ok.sum() >= 5:
        mh = 0.5 * (world[ok, L.L_HIP] + world[ok, L.R_HIP])
        ms = 0.5 * (world[ok, L.L_SHOULDER] + world[ok, R])
        seg["torso"] = float(np.median(np.linalg.norm(ms - mh, axis=-1)))
    return seg


def pelvis_frames(world: np.ndarray) -> np.ndarray:
    """(F,3,3) pelvis frames: columns x=character-left, y=forward, z=up."""
    from .quat import normalize
    lh, rh = world[:, L.L_HIP], world[:, R_HIP := L.R_HIP]
    ls, rs = world[:, L.L_SHOULDER], world[:, L.R_SHOULDER]
    _ = R_HIP
    x = normalize(lh - rh)                       # to character's left
    up_guess = normalize(0.5 * (ls + rs) - 0.5 * (lh + rh))
    # bias up toward world Z to stabilise when bending over
    z = normalize(0.6 * up_guess + 0.4 * np.array([0, 0, 1.0]))
    y = normalize(np.cross(z, x))                # forward
    z = np.cross(x, y)
    return np.stack([x, y, z], axis=-1)


def fill_occlusions(world: np.ndarray, vis: np.ndarray, fps: float,
                    conf: float, max_gap_s: float = 0.5):
    """Main entry.  Returns (world_filled, info dict).

    info:
      valid       {group: (F,) bool} trusted-or-interpolated mask
      synth_legs  (F,) bool, frames where legs are procedural
      gait        gait analysis dict
      contact_L/R (F,) 0..1 foot contact weight (tracked or synthetic)
      segments    measured body segment lengths
    """
    F = world.shape[0]
    world = np.array(world, copy=True)
    max_gap = max(1, int(round(max_gap_s * fps)))

    seg = measure_segments(world, vis, conf)
    gvalid = group_validity(vis, conf)

    # torso is the anchor: interpolate/hold it unconditionally
    torso_ids = L.GROUPS["torso"] + L.GROUPS["head"]
    for i in torso_ids:
        ok = vis[:, i] > conf * 0.6           # be lenient for the anchor
        world[:, i], _ = interpolate_gaps(world[:, i], ok, None)
        world[:, i] = hold_edges(world[:, i], ok)

    pf = pelvis_frames(world)

    # 1) per-joint short-gap interpolation; a group counts as usable on a
    #    frame when ALL of its joints are trusted or gap-filled there.
    filled = {}
    for name, ids in L.GROUPS.items():
        m = np.ones(F, bool)
        for i in ids:
            ok = vis[:, i] > conf
            world[:, i], fm = interpolate_gaps(world[:, i], ok, max_gap)
            m &= fm
        filled[name] = m if m.any() else gvalid[name]

    # 2) gait analysis from whatever is visible
    ginfo = gait.analyze_gait(world, vis, fps, conf)

    legs_missing = ~(filled["leg.L"] & filled["leg.R"])
    synth_mask = np.zeros(F, bool)
    contact_L = np.zeros(F)
    contact_R = np.zeros(F)

    if ginfo["locomoting"] and legs_missing.any():
        synth_world, cL, cR = gait.synthesize_legs(
            world, ginfo["phase"], ginfo["run_factor"], pf, seg)
        w = _blend_weight(legs_missing, fps)     # smooth 0..1 blend
        for i in (L.GROUPS["leg.L"] + L.GROUPS["leg.R"]
                  + [L.L_HIP, L.R_HIP]):
            world[:, i] = (world[:, i] * (1 - w[:, None])
                           + synth_world[:, i] * w[:, None])
        synth_mask = w > 0.5
        contact_L = np.where(synth_mask, cL, 0.0)
        contact_R = np.where(synth_mask, cR, 0.0)
    elif legs_missing.any():
        _hold_and_relax_legs(world, filled, pf, seg, fps)

    # 3) arms / head: hold-and-relax for unfilled spans
    for side in ("L", "R"):
        name = f"arm.{side}"
        _hold_and_relax_group(world, L.GROUPS[name], filled[name], pf, fps,
                              anchor=world[:, getattr(L, f"{side}_SHOULDER")])
    _hold_and_relax_group(world, L.GROUPS["head"], filled["head"], pf, fps,
                          anchor=0.5 * (world[:, L.L_SHOULDER]
                                        + world[:, L.R_SHOULDER]))

    info = {"valid": filled, "synth_legs": synth_mask, "gait": ginfo,
            "contact_L": contact_L, "contact_R": contact_R,
            "segments": seg, "pelvis_frames": pf}
    return world, info


def _blend_weight(mask: np.ndarray, fps: float, ramp_s: float = 0.25):
    """Turn a bool mask into a smooth 0..1 weight with cosine ramps."""
    w = mask.astype(float)
    r = max(1, int(round(ramp_s * fps)))
    kernel = np.hanning(2 * r + 1)
    kernel /= kernel.sum()
    pad = np.concatenate([w[:1].repeat(r), w, w[-1:].repeat(r)])
    return np.clip(np.convolve(pad, kernel, mode="valid"), 0, 1)


def _hold_and_relax_group(world, ids, valid, pf, fps, anchor,
                          relax_s: float = 1.2):
    """For invalid spans, keep the joint offsets (in the pelvis frame,
    relative to ``anchor``) from the last confident frame, then ease them
    toward their median 'neutral' offsets. Prevents both freezing in world
    space and unnatural snaps."""
    F = world.shape[0]
    if valid.all() or not valid.any():
        if not valid.any():
            return                                    # nothing to anchor to
    offs = np.stack([world[:, i] - anchor for i in ids], axis=1)  # F,N,3
    local = np.einsum("fij,fnj->fni", np.transpose(pf, (0, 2, 1)), offs)
    neutral = np.median(local[valid], axis=0)
    tau = relax_s * fps
    last = None
    t_since = 0
    for f in range(F):
        if valid[f]:
            last = local[f].copy()
            t_since = 0
            continue
        if last is None:
            local[f] = neutral
            continue
        t_since += 1
        a = 1.0 - np.exp(-t_since / tau)
        local[f] = last * (1 - a) + neutral * a
    offs = np.einsum("fij,fnj->fni", pf, local)
    for k, i in enumerate(ids):
        world[:, i] = anchor + offs[:, k]


def _hold_and_relax_legs(world, filled, pf, seg, fps):
    mid_hip = 0.5 * (world[:, L.L_HIP] + world[:, L.R_HIP])
    for side in ("L", "R"):
        _hold_and_relax_group(
            world, L.GROUPS[f"leg.{side}"], filled[f"leg.{side}"], pf, fps,
            anchor=mid_hip)
