"""Temporal filtering utilities (pure numpy).

- interpolate_gaps: fill invalid spans of a signal (used for short occlusions)
- OneEuro / one_euro: jitter removal that preserves fast motion
- savgol: Savitzky-Golay smoothing without scipy
"""
from __future__ import annotations

import numpy as np


def interpolate_gaps(x: np.ndarray, valid: np.ndarray, max_gap: int | None = None):
    """Linearly interpolate frames where ``valid`` is False.

    x:     (F, ...) signal
    valid: (F,) bool
    max_gap: gaps longer than this (frames) are left untouched.
    Returns (filled_x, filled_mask) where filled_mask marks frames that are
    now usable (originally valid or interpolated).
    """
    x = np.array(x, copy=True)
    valid = np.asarray(valid, bool)
    filled = valid.copy()
    idx = np.flatnonzero(valid)
    if idx.size == 0:
        return x, filled
    F = x.shape[0]

    # leading / trailing gaps: hold nearest valid value (no invention here;
    # occlusion strategies decide what to do with the mask later)
    flat = x.reshape(F, -1)
    prev = idx[0]
    for a, b in zip(idx[:-1], idx[1:]):
        gap = b - a - 1
        if gap <= 0:
            continue
        if max_gap is not None and gap > max_gap:
            continue
        t = (np.arange(1, gap + 1) / (gap + 1))[:, None]
        flat[a + 1:b] = flat[a] * (1 - t) + flat[b] * t
        filled[a + 1:b] = True
    x = flat.reshape(x.shape)
    _ = prev
    return x, filled


def hold_edges(x: np.ndarray, valid: np.ndarray) -> np.ndarray:
    """Copy nearest valid frame into leading/trailing invalid frames."""
    x = np.array(x, copy=True)
    idx = np.flatnonzero(valid)
    if idx.size == 0:
        return x
    x[: idx[0]] = x[idx[0]]
    x[idx[-1] + 1:] = x[idx[-1]]
    return x


# ---------------------------------------------------------------------------
class OneEuro:
    """Vectorised One Euro filter (Casiez et al. 2012)."""

    def __init__(self, freq: float, min_cutoff: float = 1.0,
                 beta: float = 0.3, d_cutoff: float = 1.0):
        self.freq = float(freq)
        self.min_cutoff = float(min_cutoff)
        self.beta = float(beta)
        self.d_cutoff = float(d_cutoff)
        self._x = None
        self._dx = None

    @staticmethod
    def _alpha(cutoff, freq):
        tau = 1.0 / (2 * np.pi * cutoff)
        te = 1.0 / freq
        return 1.0 / (1.0 + tau / te)

    def __call__(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, float)
        if self._x is None:
            self._x = x.copy()
            self._dx = np.zeros_like(x)
            return x.copy()
        dx = (x - self._x) * self.freq
        a_d = self._alpha(self.d_cutoff, self.freq)
        self._dx = a_d * dx + (1 - a_d) * self._dx
        cutoff = self.min_cutoff + self.beta * np.abs(self._dx)
        a = self._alpha(cutoff, self.freq)
        self._x = a * x + (1 - a) * self._x
        return self._x.copy()


def one_euro(x: np.ndarray, fps: float, min_cutoff=1.0, beta=0.3) -> np.ndarray:
    """Apply One Euro along axis 0 of (F, ...) array."""
    f = OneEuro(fps, min_cutoff, beta)
    return np.stack([f(frame) for frame in x], axis=0)


# ---------------------------------------------------------------------------
def _savgol_coeffs(window: int, poly: int) -> np.ndarray:
    half = window // 2
    t = np.arange(-half, half + 1, dtype=float)
    A = np.vander(t, poly + 1, increasing=True)      # (window, poly+1)
    # least squares smoothing coefficients = first row of (A^T A)^-1 A^T
    ATA_inv = np.linalg.pinv(A.T @ A)
    return (ATA_inv @ A.T)[0]                        # (window,)


def savgol(x: np.ndarray, window: int, poly: int = 3) -> np.ndarray:
    """Savitzky-Golay smoothing along axis 0, edge-padded (reflect)."""
    if window < 3:
        return np.array(x, copy=True)
    if window % 2 == 0:
        window += 1
    poly = min(poly, window - 1)
    c = _savgol_coeffs(window, poly)
    half = window // 2
    F = x.shape[0]
    if F < window:
        return np.array(x, copy=True)
    flat = x.reshape(F, -1)
    pad = np.concatenate([flat[half:0:-1], flat, flat[-2:-half - 2:-1]], axis=0)
    out = np.empty_like(flat)
    for j in range(flat.shape[1]):
        out[:, j] = np.convolve(pad[:, j], c[::-1], mode="valid")
    return out.reshape(x.shape)


def smoothing_params(level: float, fps: float):
    """Map the UI 0..1 'Smoothing Level' to filter parameters."""
    level = float(np.clip(level, 0.0, 1.0))
    min_cutoff = 3.0 - 2.6 * level          # 3.0 (light) .. 0.4 (heavy)
    beta = 0.5 - 0.35 * level
    win = int(round(3 + level * max(4, fps * 0.35)))
    if win % 2 == 0:
        win += 1
    return min_cutoff, beta, win
