"""Video -> raw landmark arrays using MediaPipe Pose Landmarker (Tasks API).

This module deliberately knows nothing about Blender.  It requires the
optional runtime dependency ``mediapipe`` (which bundles OpenCV); the add-on
installs it on demand via deps.py.

Output convention:
  world  (F,33,3)  hip-centered metric coordinates, converted to Blender
                   axes: +X right(image), +Y away from camera, +Z up
  image  (F,33,2)  normalized image coordinates (x right, y down)
  vis    (F,33)    visibility score 0..1 (0 for frames with no detection)
  fps, width, height
"""
from __future__ import annotations

import os
import urllib.request

import numpy as np

MODEL_URLS = {
    "heavy": ("https://storage.googleapis.com/mediapipe-models/pose_landmarker/"
              "pose_landmarker_heavy/float16/latest/pose_landmarker_heavy.task"),
    "full": ("https://storage.googleapis.com/mediapipe-models/pose_landmarker/"
             "pose_landmarker_full/float16/latest/pose_landmarker_full.task"),
    "lite": ("https://storage.googleapis.com/mediapipe-models/pose_landmarker/"
             "pose_landmarker_lite/float16/latest/pose_landmarker_lite.task"),
}


class DependencyError(RuntimeError):
    pass


def _import_mediapipe():
    try:
        import mediapipe as mp  # noqa: F401
        import cv2  # noqa: F401
    except ImportError as e:
        raise DependencyError(
            "The 'mediapipe' package is not installed in Blender's Python. "
            "Use the 'Install Dependencies' button in the add-on panel."
        ) from e
    import mediapipe
    import cv2
    return mediapipe, cv2


def model_dir() -> str:
    d = os.path.join(os.path.expanduser("~"), ".video_mocap_retarget")
    os.makedirs(d, exist_ok=True)
    return d


def ensure_model(quality: str = "heavy", progress=None) -> str:
    """Return local path to the .task model, downloading it if missing."""
    url = MODEL_URLS[quality]
    path = os.path.join(model_dir(), os.path.basename(url))
    if os.path.isfile(path) and os.path.getsize(path) > 1_000_000:
        return path
    tmp = path + ".part"
    try:
        def _hook(blocks, bs, total):
            if progress and total > 0:
                progress(min(blocks * bs / total, 1.0),
                         "Downloading pose model...")
        urllib.request.urlretrieve(url, tmp, reporthook=_hook)
        os.replace(tmp, path)
    except Exception as e:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise RuntimeError(
            f"Could not download the pose model ({e}). Check your internet "
            f"connection, or download it manually from\n{url}\nand place it "
            f"at\n{path}"
        ) from e
    return path


def _mp_to_blender(pts: np.ndarray) -> np.ndarray:
    """MediaPipe world axes (x right, y down, z toward camera) -> Blender
    (x right, y forward/away-from-camera, z up)."""
    out = np.empty_like(pts)
    out[..., 0] = pts[..., 0]
    out[..., 1] = -pts[..., 2]
    out[..., 2] = -pts[..., 1]
    return out


def extract_landmarks(video_path: str, quality: str = "heavy",
                      progress=None, cancel=None):
    """Run pose detection over a video file.

    progress: optional callable(fraction, message)
    cancel:   optional callable() -> bool ; True aborts

    Returns dict with keys world, image, vis, fps, width, height, n_frames.
    """
    mp, cv2 = _import_mediapipe()
    from mediapipe.tasks.python import BaseOptions, vision

    if not os.path.isfile(video_path):
        raise FileNotFoundError(f"Video not found: {video_path}")

    model_path = ensure_model(quality, progress)

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"OpenCV could not open the video: {video_path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    if not np.isfinite(fps) or fps <= 1:
        fps = 30.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0

    options = vision.PoseLandmarkerOptions(
        base_options=BaseOptions(model_asset_path=model_path),
        running_mode=vision.RunningMode.VIDEO,
        num_poses=1,
        min_pose_detection_confidence=0.5,
        min_pose_presence_confidence=0.5,
        min_tracking_confidence=0.5,
    )

    world_l, image_l, vis_l = [], [], []
    frame_i = 0
    with vision.PoseLandmarker.create_from_options(options) as landmarker:
        while True:
            if cancel and cancel():
                break
            ok, frame_bgr = cap.read()
            if not ok:
                break
            rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            mp_img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
            ts_ms = int(round(frame_i * 1000.0 / fps))
            res = landmarker.detect_for_video(mp_img, ts_ms)
            if res.pose_world_landmarks:
                wl = res.pose_world_landmarks[0]
                il = res.pose_landmarks[0]
                world_l.append([[p.x, p.y, p.z] for p in wl])
                image_l.append([[p.x, p.y] for p in il])
                vis_l.append([getattr(p, "visibility", 1.0) or 0.0 for p in wl])
            else:
                world_l.append([[0.0, 0.0, 0.0]] * 33)
                image_l.append([[0.5, 0.5]] * 33)
                vis_l.append([0.0] * 33)
            frame_i += 1
            if progress and total:
                progress(frame_i / total, f"Analyzing frame {frame_i}/{total}")
    cap.release()

    if frame_i == 0:
        raise RuntimeError("No frames could be read from the video.")

    world = _mp_to_blender(np.asarray(world_l, np.float64))
    return {
        "world": world,
        "image": np.asarray(image_l, np.float64),
        "vis": np.asarray(vis_l, np.float64),
        "fps": float(fps),
        "width": width,
        "height": height,
        "n_frames": frame_i,
    }
