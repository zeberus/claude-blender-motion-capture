"""Bone mapping between the canonical skeleton and a target rig.

A mapping is a plain dict:

{
  "name": "Rigify (IK legs)",
  "mode": "rigify_ik" | "fk",
  "bones": { canonical_bone: target_bone_name, ... },
  "ik": {                       # only for rigify_ik mode
     "foot.L": "foot_ik.L", "foot.R": "foot_ik.R",
     "pole.L": "thigh_ik_target.L", "pole.R": "thigh_ik_target.R",
     "torso": "torso"
  },
  "root_bone": "torso",          # receives root translation
}

Serialisable to/from JSON so users can save custom rig maps.
"""
from __future__ import annotations

import json
import re

CANON_FOR_UI = [
    "root", "spine", "chest", "neck", "head",
    "shoulder.L", "upper_arm.L", "forearm.L", "hand.L",
    "shoulder.R", "upper_arm.R", "forearm.R", "hand.R",
    "thigh.L", "shin.L", "foot.L", "toe.L",
    "thigh.R", "shin.R", "foot.R", "toe.R",
]

# ---------------------------------------------------------------------------
RIGIFY_IK = {
    "name": "Rigify (IK legs)",
    "mode": "rigify_ik",
    "root_bone": "torso",
    "bones": {
        "root": "torso",           # translation+rotation target
        "spine": "hips",           # note: rigify 'hips' rotates the lower spine
        "chest": "chest",
        "neck": "neck",
        "head": "head",
        "shoulder.L": "shoulder.L", "shoulder.R": "shoulder.R",
        "upper_arm.L": "upper_arm_fk.L", "forearm.L": "forearm_fk.L",
        "hand.L": "hand_fk.L",
        "upper_arm.R": "upper_arm_fk.R", "forearm.R": "forearm_fk.R",
        "hand.R": "hand_fk.R",
    },
    "ik": {
        "foot.L": "foot_ik.L", "foot.R": "foot_ik.R",
        "pole.L": "thigh_ik_target.L", "pole.R": "thigh_ik_target.R",
    },
    "settings": {"arm_ik_fk": 1.0, "leg_ik_fk": 0.0},
}

RIGIFY_FK = {
    "name": "Rigify (FK legs)",
    "mode": "fk",
    "root_bone": "torso",
    "bones": dict(RIGIFY_IK["bones"], **{
        "thigh.L": "thigh_fk.L", "shin.L": "shin_fk.L",
        "foot.L": "foot_fk.L", "toe.L": "toe_fk.L",
        "thigh.R": "thigh_fk.R", "shin.R": "shin_fk.R",
        "foot.R": "foot_fk.R", "toe.R": "toe_fk.R",
    }),
    "settings": {"arm_ik_fk": 1.0, "leg_ik_fk": 1.0},
}

MIXAMO = {
    "name": "Mixamo",
    "mode": "fk",
    "root_bone": "mixamorig:Hips",
    "bones": {
        "root": "mixamorig:Hips", "spine": "mixamorig:Spine",
        "chest": "mixamorig:Spine2", "neck": "mixamorig:Neck",
        "head": "mixamorig:Head",
        "shoulder.L": "mixamorig:LeftShoulder",
        "upper_arm.L": "mixamorig:LeftArm",
        "forearm.L": "mixamorig:LeftForeArm", "hand.L": "mixamorig:LeftHand",
        "shoulder.R": "mixamorig:RightShoulder",
        "upper_arm.R": "mixamorig:RightArm",
        "forearm.R": "mixamorig:RightForeArm", "hand.R": "mixamorig:RightHand",
        "thigh.L": "mixamorig:LeftUpLeg", "shin.L": "mixamorig:LeftLeg",
        "foot.L": "mixamorig:LeftFoot", "toe.L": "mixamorig:LeftToeBase",
        "thigh.R": "mixamorig:RightUpLeg", "shin.R": "mixamorig:RightLeg",
        "foot.R": "mixamorig:RightFoot", "toe.R": "mixamorig:RightToeBase",
    },
}

UE_MANNEQUIN = {
    "name": "Unreal Mannequin",
    "mode": "fk",
    "root_bone": "pelvis",
    "bones": {
        "root": "pelvis", "spine": "spine_01", "chest": "spine_03",
        "neck": "neck_01", "head": "head",
        "shoulder.L": "clavicle_l", "upper_arm.L": "upperarm_l",
        "forearm.L": "lowerarm_l", "hand.L": "hand_l",
        "shoulder.R": "clavicle_r", "upper_arm.R": "upperarm_r",
        "forearm.R": "lowerarm_r", "hand.R": "hand_r",
        "thigh.L": "thigh_l", "shin.L": "calf_l",
        "foot.L": "foot_l", "toe.L": "ball_l",
        "thigh.R": "thigh_r", "shin.R": "calf_r",
        "foot.R": "foot_r", "toe.R": "ball_r",
    },
}

PRESETS = {
    "RIGIFY_IK": RIGIFY_IK,
    "RIGIFY_FK": RIGIFY_FK,
    "MIXAMO": MIXAMO,
    "UE_MANNEQUIN": UE_MANNEQUIN,
}

# ---------------------------------------------------------------------------
# Auto-detection for arbitrary rigs
# ---------------------------------------------------------------------------
_SIDE_L = re.compile(
    r"left|(^|[._\-\s])l([._\-\s]|$)|[._\-]l$|^l[._\-]", re.I)
_SIDE_R = re.compile(
    r"right|(^|[._\-\s])r([._\-\s]|$)|[._\-]r$|^r[._\-]", re.I)

_PATTERNS = {
    "root": ["hips", "pelvis", "hip", "root", "torso", "cog"],
    "spine": ["spine1", "spine_01", "spine.001", "spine01", "spine", "waist",
              "abdomen"],
    "chest": ["chest", "spine3", "spine_03", "spine.003", "spine2", "upperchest",
              "thorax"],
    "neck": ["neck"],
    "head": ["head"],
    "shoulder": ["clavicle", "shoulder", "collar"],
    "upper_arm": ["upperarm", "upper_arm", "uparm", "arm"],
    "forearm": ["forearm", "lowerarm", "lower_arm", "elbow"],
    "hand": ["hand", "wrist"],
    "thigh": ["thigh", "upleg", "upperleg", "up_leg", "leg"],
    "shin": ["shin", "calf", "lowerleg", "lowleg", "knee", "leg"],
    "foot": ["foot", "ankle"],
    "toe": ["toe", "ball"],
}

_SIDED = {"shoulder", "upper_arm", "forearm", "hand",
          "thigh", "shin", "foot", "toe"}


def _norm(name: str) -> str:
    return re.sub(r"[._\-\s]", "", name.lower())


def _side_of(name: str):
    if _SIDE_L.search(name):
        return "L"
    if _SIDE_R.search(name):
        return "R"
    return None


def guess_mapping(bone_names, deform_only_hint=True):
    """Heuristic canonical->target mapping for an arbitrary rig.

    Skips obvious helper bones (ORG-/MCH-/DEF-/VIS-/WGT prefixes) so
    Rigify-like rigs resolve to their animator-facing controls.
    """
    skip = re.compile(r"^(org|mch|vis|wgt)[\-_.]", re.I)
    candidates = [b for b in bone_names if not skip.match(b)]
    if not candidates:
        candidates = list(bone_names)
    _ = deform_only_hint

    out = {}
    used = set()
    for canon, pats in _PATTERNS.items():
        sided = canon in _SIDED
        for side in (("L", "R") if sided else (None,)):
            best = None
            for b in candidates:
                if b in used:
                    continue
                if sided and _side_of(b) != side:
                    continue
                if not sided and _side_of(b) is not None and canon != "root":
                    continue
                nb = _norm(b)
                for rank, p in enumerate(pats):
                    if _norm(p) in nb:
                        score = (rank, len(nb))
                        if best is None or score < best[0]:
                            best = (score, b)
                        break
            if best:
                key = f"{canon}.{side}" if sided else canon
                out[key] = best[1]
                used.add(best[1])
    return {"name": "Auto-detected", "mode": "fk",
            "root_bone": out.get("root", ""), "bones": out}


def to_json(mapping: dict) -> str:
    return json.dumps(mapping, indent=2)


def from_json(text: str) -> dict:
    m = json.loads(text)
    if "bones" not in m or not isinstance(m["bones"], dict):
        raise ValueError("Mapping JSON must contain a 'bones' object")
    m.setdefault("mode", "fk")
    m.setdefault("root_bone", m["bones"].get("root", ""))
    m.setdefault("name", "Custom")
    return m


def validate(mapping: dict, bone_names) -> list[str]:
    """Return list of human-readable problems (empty = OK)."""
    problems = []
    names = set(bone_names)
    for canon, target in mapping.get("bones", {}).items():
        if target and target not in names:
            problems.append(f"'{target}' (for {canon}) not found in armature")
    for k, target in mapping.get("ik", {}).items():
        if target and target not in names:
            problems.append(f"IK bone '{target}' ({k}) not found in armature")
    if not mapping.get("bones", {}).get("root"):
        problems.append("No root/pelvis bone mapped")
    return problems
