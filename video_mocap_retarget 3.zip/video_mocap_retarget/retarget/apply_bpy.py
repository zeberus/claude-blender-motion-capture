"""Apply a solved MotionClip to a Blender armature.  bpy-only module.

Retarget method: direction-exact world matching with per-bone twist
calibration.

  For each mapped bone we build, per frame, a desired world orientation from
  the canonical bone's current direction and bending-plane normal, then add
  a constant twist offset measured at calibration time so the target bone's
  rest roll is respected.  This makes the character's limbs *point where the
  performer's limbs point*, regardless of whether the rig rests in T-pose or
  A-pose, and regardless of bone rolls.

Rigify mode drives:
  torso            location + rotation  (root motion)
  hips/chest/...   rotation (FK)
  arm FK chain     rotation
  foot_ik.L/R      location + rotation  -> natural foot planting
  thigh_ik_target  location             (knee poles)
and sets the IK/FK switches accordingly.
"""
from __future__ import annotations

import numpy as np

import bpy
from mathutils import Matrix, Vector

from ..analysis.pipeline import MotionClip, frame_times
from ..analysis.quat import frame_from_dir_normal

FORWARD_ROT = {
    "NEG_Y": 0.0,          # Blender character convention: faces -Y
    "POS_Y": np.pi,
    "POS_X": -np.pi / 2,
    "NEG_X": np.pi / 2,
}


def _rz(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


class Calibration:
    """Per-bone constant data computed once from rest poses."""

    def __init__(self, arm_obj, mapping, clip: MotionClip, forward="NEG_Y"):
        self.arm = arm_obj
        self.mapping = mapping
        # canonical space faces +Y; rotate into the character's forward
        self.conv = _rz(FORWARD_ROT[forward] + np.pi)
        self.twist = {}          # canon bone -> float (radians)
        self.scale = 1.0
        self._calibrate(clip)

    # -- helpers ------------------------------------------------------------
    def _rest_world(self, bone_name):
        b = self.arm.data.bones.get(bone_name)
        if b is None:
            return None
        m = self.arm.matrix_world @ b.matrix_local
        return np.array(m.to_3x3()), np.array(m.translation)

    def _calibrate(self, clip):
        from ..analysis.landmarks import CANON_REST

        # character/performer scale from hip height
        root_t = self.mapping["bones"].get("root")
        perf_h = float(np.median(clip.root_trans[:, 2]))
        if root_t:
            rw = self._rest_world(root_t)
            if rw is not None and perf_h > 0.2:
                char_h = float(rw[1][2])
                if char_h > 0.05:
                    self.scale = char_h / perf_h
        # twist offsets
        for canon, target in self.mapping.get("bones", {}).items():
            self._twist_for(canon, target, CANON_REST)
        for key, target in self.mapping.get("ik", {}).items():
            if key.startswith("foot"):
                canon = "foot." + key[-1]
                self._twist_for(canon, target, CANON_REST, store_as=key)

    def _twist_for(self, canon, target, CANON_REST, store_as=None):
        if canon not in CANON_REST or not target:
            return
        rw = self._rest_world(target)
        if rw is None:
            return
        R_t, _ = rw
        y_t = R_t[:, 1]
        z_t = R_t[:, 2]
        d, n = CANON_REST[canon]
        y_c = self.conv @ np.asarray(d, float)
        n_c = self.conv @ np.asarray(n, float)
        # swing canonical rest direction onto target rest direction
        q = _shortest_arc(y_c, y_t)
        n_c2 = q @ n_c
        # project both normals perpendicular to y_t, measure signed angle
        n_c2 = n_c2 - np.dot(n_c2, y_t) * y_t
        z_p = z_t - np.dot(z_t, y_t) * y_t
        if np.linalg.norm(n_c2) < 1e-6 or np.linalg.norm(z_p) < 1e-6:
            theta = 0.0
        else:
            n_c2 /= np.linalg.norm(n_c2)
            z_p /= np.linalg.norm(z_p)
            theta = np.arctan2(np.dot(np.cross(n_c2, z_p), y_t),
                               np.clip(np.dot(n_c2, z_p), -1, 1))
        self.twist[store_as or canon] = float(theta)


def _shortest_arc(a, b):
    """3x3 rotation taking unit vector a to b."""
    a = a / max(np.linalg.norm(a), 1e-9)
    b = b / max(np.linalg.norm(b), 1e-9)
    v = np.cross(a, b)
    c = float(np.dot(a, b))
    if c < -1 + 1e-8:
        axis = np.cross(a, [1.0, 0, 0])
        if np.linalg.norm(axis) < 1e-6:
            axis = np.cross(a, [0, 1.0, 0])
        axis /= np.linalg.norm(axis)
        return _axis_angle(axis, np.pi)
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + vx + vx @ vx / (1 + c)


def _axis_angle(axis, angle):
    x, y, z = axis
    c, s, C = np.cos(angle), np.sin(angle), 1 - np.cos(angle)
    return np.array([
        [c + x * x * C, x * y * C - z * s, x * z * C + y * s],
        [y * x * C + z * s, c + y * y * C, y * z * C - x * s],
        [z * x * C - y * s, z * y * C + x * s, c + z * z * C]])


def _ry(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


# ---------------------------------------------------------------------------
def desired_world_rot(clip: MotionClip, calib: Calibration, canon: str,
                      f: int, twist_key=None) -> np.ndarray:
    """3x3 desired world rotation for canonical bone at frame f."""
    pos = clip.pos[canon][f]
    tl = clip.tail[canon][f]
    d = tl - pos
    # bending normal = column z of the solved frame; rebuild from quats to
    # avoid storing full frames: use stored quats -> frame
    from ..analysis.quat import mat_from_quat
    Fm = mat_from_quat(clip.quats[canon][f])
    n = Fm[:, 2]
    d = calib.conv @ d
    n = calib.conv @ n
    B = frame_from_dir_normal(d[None, :], n[None, :])[0]
    theta = calib.twist.get(twist_key or canon, 0.0)
    return B @ _ry(theta)


def _pos_world(clip, calib, canon, f):
    return calib.conv @ (clip.pos[canon][f] * calib.scale)


# ---------------------------------------------------------------------------
STAGES = [  # bones assigned per stage, depsgraph update between stages
    ["root"],
    ["spine", "chest"],
    ["neck", "head", "shoulder.L", "shoulder.R"],
    ["upper_arm.L", "upper_arm.R", "thigh.L", "thigh.R"],
    ["forearm.L", "forearm.R", "shin.L", "shin.R"],
    ["hand.L", "hand.R", "foot.L", "foot.R", "toe.L", "toe.R"],
]


def apply_clip(context, arm_obj, clip: MotionClip, mapping: dict,
               speed: float = 1.0, forward: str = "NEG_Y",
               action_name: str = "Mocap", progress=None,
               start_frame: int | None = None):
    """Keyframe the clip onto arm_obj.  Returns an undo record dict."""
    scene = context.scene
    calib = Calibration(arm_obj, mapping, clip, forward)

    undo = {
        "armature": arm_obj.name,
        "prev_action": (arm_obj.animation_data.action.name
                        if arm_obj.animation_data and
                        arm_obj.animation_data.action else None),
        "prev_frame": scene.frame_current,
        "ikfk": {},
    }

    if arm_obj.animation_data is None:
        arm_obj.animation_data_create()
    action = bpy.data.actions.new(action_name)
    arm_obj.animation_data.action = action
    # Blender 4.4+/5.x layered actions need a slot assigned
    if hasattr(action, "slots"):
        try:
            slot = action.slots.new(id_type='OBJECT', name=arm_obj.name)
            arm_obj.animation_data.action_slot = slot
        except Exception:
            pass
    undo["new_action"] = action.name

    rig_ik = mapping.get("mode") == "rigify_ik"
    if rig_ik:
        _set_rigify_switches(arm_obj, mapping, undo)

    pbones = arm_obj.pose.bones
    bone_map = {c: pbones.get(t) for c, t in mapping.get("bones", {}).items()
                if t and pbones.get(t)}
    ik_map = {k: pbones.get(t) for k, t in mapping.get("ik", {}).items()
              if t and pbones.get(t)}

    for pb in list(bone_map.values()) + list(ik_map.values()):
        pb.rotation_mode = 'QUATERNION'

    times = frame_times(clip, scene.render.fps / scene.render.fps_base, speed)
    if start_frame is None:
        start_frame = scene.frame_start
    times = times - times[0] + start_frame
    frames_int = np.round(times).astype(int)
    # avoid stacking several clip frames onto one scene frame
    keep = np.ones(clip.n_frames, bool)
    keep[1:] = frames_int[1:] > frames_int[:-1]

    aw_inv = np.array(arm_obj.matrix_world.inverted().to_3x3())
    aw_inv4 = arm_obj.matrix_world.inverted()

    root_canon = "root"
    total = int(keep.sum())
    done = 0
    for f in range(clip.n_frames):
        if not keep[f]:
            continue
        scene.frame_set(int(frames_int[f]))
        for stage in STAGES:
            touched = False
            for canon in stage:
                pb = bone_map.get(canon)
                if pb is None:
                    continue
                if rig_ik and canon.split(".")[0] in ("thigh", "shin",
                                                      "foot", "toe"):
                    continue          # legs handled by IK targets
                R = desired_world_rot(clip, calib, canon, f)
                R_arm = aw_inv @ R
                m = pb.matrix.copy()
                loc = m.translation.copy()
                M = Matrix((
                    (R_arm[0][0], R_arm[0][1], R_arm[0][2], loc.x),
                    (R_arm[1][0], R_arm[1][1], R_arm[1][2], loc.y),
                    (R_arm[2][0], R_arm[2][1], R_arm[2][2], loc.z),
                    (0.0, 0.0, 0.0, 1.0)))
                if canon == root_canon:
                    p = _pos_world(clip, calib, root_canon, f)
                    p_arm = aw_inv4 @ Vector(p)
                    M.translation = p_arm
                pb.matrix = M
                if canon != root_canon:
                    pb.location = (0.0, 0.0, 0.0)
                touched = True
            if touched:
                context.view_layer.update()

        if rig_ik:
            _apply_ik_feet(context, clip, calib, ik_map, aw_inv, aw_inv4, f)

        # keyframes
        fr = float(frames_int[f])
        for canon, pb in bone_map.items():
            if rig_ik and canon.split(".")[0] in ("thigh", "shin", "foot",
                                                  "toe"):
                continue
            pb.keyframe_insert("rotation_quaternion", frame=fr, group=pb.name)
            if canon == root_canon:
                pb.keyframe_insert("location", frame=fr, group=pb.name)
        for key, pb in ik_map.items():
            if key.startswith("foot"):
                pb.keyframe_insert("rotation_quaternion", frame=fr,
                                   group=pb.name)
                pb.keyframe_insert("location", frame=fr, group=pb.name)
            else:
                pb.keyframe_insert("location", frame=fr, group=pb.name)

        done += 1
        if progress and done % 5 == 0:
            progress(done / total, f"Keyframing {done}/{total}")

    undo["frame_range"] = (int(frames_int[0]), int(frames_int[keep][-1])
                           if keep.any() else int(frames_int[0]))
    scene.frame_set(int(frames_int[0]))
    return undo


def _apply_ik_feet(context, clip, calib, ik_map, aw_inv, aw_inv4, f):
    changed = False
    for side in ("L", "R"):
        pb = ik_map.get(f"foot.{side}")
        if pb is not None:
            canon = f"foot.{side}"
            R = desired_world_rot(clip, calib, canon, f,
                                  twist_key=f"foot.{side}")
            R_arm = aw_inv @ R
            p = _pos_world(clip, calib, canon, f)
            p_arm = aw_inv4 @ Vector(p)
            M = Matrix((
                (R_arm[0][0], R_arm[0][1], R_arm[0][2], p_arm.x),
                (R_arm[1][0], R_arm[1][1], R_arm[1][2], p_arm.y),
                (R_arm[2][0], R_arm[2][1], R_arm[2][2], p_arm.z),
                (0.0, 0.0, 0.0, 1.0)))
            pb.matrix = M
            changed = True
        pole = ik_map.get(f"pole.{side}")
        if pole is not None:
            hip = clip.pos[f"thigh.{side}"][f]
            knee = clip.pos[f"shin.{side}"][f]
            ankle = clip.pos[f"foot.{side}"][f]
            out_dir = (knee - hip) + (knee - ankle)
            n = np.linalg.norm(out_dir)
            if n < 1e-5:
                # straight leg: push the pole forward (canonical +Y)
                out_dir = np.array([0.0, 1.0, 0.0])
                n = 1.0
            pole_p = knee + out_dir / n * 0.45
            p = calib.conv @ (pole_p * calib.scale)
            m = pole.matrix.copy()
            m.translation = aw_inv4 @ Vector(p)
            pole.matrix = m
            changed = True
    if changed:
        context.view_layer.update()


def _set_rigify_switches(arm_obj, mapping, undo):
    """Arms FK, legs IK; remember previous values for undo."""
    want = {"upper_arm_parent.L": 1.0, "upper_arm_parent.R": 1.0,
            "thigh_parent.L": 0.0, "thigh_parent.R": 0.0}
    for name, val in want.items():
        pb = arm_obj.pose.bones.get(name)
        if pb is None:
            continue
        for prop in ("IK_FK", "IK/FK", "ik_fk"):
            if prop in pb.keys():
                undo["ikfk"][(name, prop)] = pb[prop]
                pb[prop] = val
                break


# ---------------------------------------------------------------------------
def undo_application(undo: dict) -> str:
    arm = bpy.data.objects.get(undo.get("armature", ""))
    if arm is None:
        return "Armature no longer exists"
    act = bpy.data.actions.get(undo.get("new_action", ""))
    prev = undo.get("prev_action")
    if arm.animation_data:
        arm.animation_data.action = bpy.data.actions.get(prev) if prev else None
    if act is not None:
        bpy.data.actions.remove(act)
    for (bone, prop), val in undo.get("ikfk", {}).items():
        pb = arm.pose.bones.get(bone)
        if pb is not None and prop in pb.keys():
            pb[prop] = val
    # reset pose transforms the apply loop touched
    for pb in arm.pose.bones:
        pb.matrix_basis.identity()
    return ""
