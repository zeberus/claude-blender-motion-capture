"""Retargeting: bone mapping model (pure python) + bpy application layer."""
